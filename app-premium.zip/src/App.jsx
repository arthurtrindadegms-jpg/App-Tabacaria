import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { data } from "./data";
import Card from "./components/Card";
import TabBar from "./components/TabBar";
import Modal from "./components/Modal";

export default function App() {
  const [tab, setTab] = useState("blends");
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    document.body.style.background = "#0f0f0f";
  }, [tab]);

  return (
    <div className="app">
      <motion.h1 layout className="title">
        {tab.toUpperCase()}
      </motion.h1>

      <motion.div layout className="grid">
        <AnimatePresence>
          {data[tab].map((item, i) => (
            <Card
              key={item.name}
              item={item}
              index={i}
              tab={tab}
              onClick={() => setSelected(item)}
            />
          ))}
        </AnimatePresence>
      </motion.div>

      <TabBar active={tab} setTab={setTab} />

      <AnimatePresence>
        {selected && (
          <Modal item={selected} onClose={() => setSelected(null)} />
        )}
      </AnimatePresence>
    </div>
  );
}