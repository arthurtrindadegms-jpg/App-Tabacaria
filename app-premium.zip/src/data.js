export const data = {
  blends: [
    {
      name: "Zomo",
      color: "#E30613",
      logo: "/assets/logos/zomo.webp",
      info: "Strong Mint, Love 66"
    },
    {
      name: "Ziggy",
      color: "#6A0DAD",
      logo: "/assets/logos/ziggy.webp",
      info: "Purple Wave"
    }
  ],
  energy: [
    {
      name: "Zeus",
      color: "#FFD600",
      logo: "/assets/logos/zeus.webp",
      info: "Carvão Premium"
    }
  ],
  foil: [
    {
      name: "Predator",
      color: "#B0BEC5",
      logo: "/assets/logos/predator.webp",
      info: "Alumínio resistente"
    }
  ]
};
