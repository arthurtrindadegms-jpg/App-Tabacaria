import { motion } from "framer-motion";

const tabs = ["blends", "energy", "foil"];

export default function TabBar({ active, setTab }) {
  return (
    <div className="tabbar">
      {tabs.map(tab => (
        <motion.button
          key={tab}
          onClick={() => setTab(tab)}
          className={active === tab ? "active" : ""}
          whileTap={{ scale: 0.85 }}
        >
          {tab}
        </motion.button>
      ))}
    </div>
  );
}