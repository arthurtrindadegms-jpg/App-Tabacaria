import { motion } from "framer-motion";

export default function Modal({ item, onClose }) {
  return (
    <motion.div
      className="modal"
      onClick={onClose}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      <motion.div
        className="modal-content"
        layoutId={`logo-${item.name}`}
        onClick={e => e.stopPropagation()}
        initial={{ scale: 0.7, y: 100 }}
        animate={{
          scale: 1,
          y: 0,
          transition: {
            type: "spring",
            damping: 15
          }
        }}
      >
        <img src={item.logo} />
        <h2>{item.name}</h2>
        <p>{item.info}</p>
      </motion.div>
    </motion.div>
  );
}