import { motion } from "framer-motion";

export default function Card({ item, index, tab, onClick }) {
  return (
    <motion.div
      className={`card ${tab}`}
      onClick={onClick}
      initial={{ opacity: 0, y: 40 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      transition={{
        delay: index * 0.05,
        type: "spring",
        stiffness: 120
      }}
      whileTap={{ scale: 0.9 }}
      whileHover={{ scale: 1.05 }}
    >
      <motion.img
        src={item.logo}
        layoutId={`logo-${item.name}`}
      />
      <h3>{item.name}</h3>
    </motion.div>
  );
}